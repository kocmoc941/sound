# stm32-sdcard
STM32 HAL-based library for SDHC/SDXC-cards

See also: https://github.com/afiskon/stm32-fatfs-examples
